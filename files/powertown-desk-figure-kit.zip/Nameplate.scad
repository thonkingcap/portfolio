// =====================================================
//  POWERTOWN DESK FIGURE: NAMEPLATE BASE
//  1. Change NAME and TITLE below.
//  2. Press F6 (Render), then File > Export > Export as STL.
//  The font "Kaisei Decol Bold" must be installed (see fonts folder).
// =====================================================

NAME  = "Elson";
TITLE = "CEO";

// ---------- You shouldn't need to change anything below ----------
BW = 95; BD = 34; BH = 22;      // base size, mm
SINK = 4; CL = 0.2;             // logo pocket depth and clearance, mm
ENG = 1.2;                      // engraving depth, mm
NAME_SIZE = 9; TITLE_SIZE = 5.5;
GAP = 4; RULE = 0.8; RULE_H = 7;
MAX_W = BW * 0.86;              // text never wider than this
FONT = "Kaisei Decol:style=Bold";
$fn = 48;

ADV_BOLD = [0.25, 0.4, 0.39, 0.78, 0.7, 0.886, 0.758, 0.28, 0.45, 0.45, 0.45, 0.75, 0.35, 0.4, 0.35, 0.5, 0.59, 0.59, 0.59, 0.59, 0.59, 0.59, 0.59, 0.59, 0.59, 0.59, 0.39, 0.39, 0.78, 0.75, 0.78, 0.56, 0.9, 0.774, 0.694, 0.725, 0.821, 0.674, 0.61, 0.781, 0.837, 0.413, 0.456, 0.722, 0.67, 0.947, 0.78, 0.82, 0.624, 0.82, 0.707, 0.594, 0.69, 0.756, 0.754, 1.0, 0.765, 0.693, 0.645, 0.45, 0.5, 0.45, 0.56, 0.5, 0.39, 0.544, 0.61, 0.54, 0.606, 0.545, 0.39, 0.552, 0.636, 0.344, 0.38, 0.592, 0.346, 0.92, 0.632, 0.62, 0.608, 0.608, 0.444, 0.446, 0.372, 0.628, 0.574, 0.852, 0.572, 0.594, 0.48, 0.45, 0.25, 0.45, 0.7];
function adv(s, t, i=0) = i >= len(s) ? 0 :
    let(c = ord(s[i])) ((c >= 32 && c < 127) ? t[c-32] : 0.6) + adv(s, t, i+1);
function w(s, t, size) = adv(s, t) * size * 1.333;

raw = w(NAME, ADV_BOLD, NAME_SIZE) + 2*GAP + RULE + w(TITLE, ADV_BOLD, TITLE_SIZE);
k   = min(1, MAX_W / raw);       // shrink long names to fit
ns = NAME_SIZE * k; ts = TITLE_SIZE * k; gap = GAP * k;
nw = w(NAME, ADV_BOLD, ns); tw = w(TITLE, ADV_BOLD, ts);
total = nw + 2*gap + RULE + tw;
x0 = -total / 2;
baseline = BH/2 - ns * 0.49;

module rr(w, h, r) { offset(r=r) square([w-2*r, h-2*r], center=true); }

difference() {
    translate([0, BD/2, 0]) linear_extrude(BH) rr(BW, BD, 2);
    // press-fit pocket for the logo's bottom bar
    translate([-37.5-CL, 9.65-CL, BH-SINK]) cube([20.7+2*CL, 12+2*CL, SINK+1]);
    // engraved name | divider | title
    translate([x0, ENG, baseline]) rotate([90,0,0]) linear_extrude(ENG+0.01)
        text(NAME, size=ns, font=FONT);
    translate([x0 + nw + gap, -0.01, BH/2 - RULE_H*k/2]) cube([RULE, ENG+0.01, RULE_H*k]);
    translate([x0 + nw + 2*gap + RULE, ENG, baseline]) rotate([90,0,0]) linear_extrude(ENG+0.01)
        text(TITLE, size=ts, font=FONT);
}
