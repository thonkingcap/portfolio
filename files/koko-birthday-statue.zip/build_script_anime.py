import sys, json, glob, numpy as np, trimesh
from manifold3d import Manifold, Mesh, CrossSection, FillRule, JoinType
from matplotlib.textpath import TextPath
from matplotlib.font_manager import FontProperties

IN, OUT = sys.argv[1], sys.argv[2]
cfg = dict(koko_h=100.0, dani_rel=0.55, dani_yaw=22, koko_yaw=-14,
           dani_x=-26, koko_x=22, dani_y=-6, koko_y=-5, ped_h=42,
           front_text="HAPPY BIRTHDAY KOKO!", jp_text="お誕生日おめでとう", back_text="DANI & KOKO  2026",
           font="/System/Library/Fonts/Supplemental/Impact.ttf",
           jp_font=glob.glob("/System/Library/Fonts/*W8.ttc")[0])
if len(sys.argv) > 3: cfg.update(json.loads(sys.argv[3]))
rng = np.random.default_rng(7)

def to_man(tm): return Manifold(Mesh(vert_properties=np.asarray(tm.vertices, np.float32), tri_verts=np.asarray(tm.faces, np.uint32)))
def to_tm(man):
    m = man.to_mesh(); return trimesh.Trimesh(m.vert_properties[:, :3], m.tri_verts, process=False)
def align(v):
    T = trimesh.geometry.align_vectors([0, 0, 1], np.asarray(v, float) / np.linalg.norm(v)); return T[:3, :]
def cyl_along(p, v, h, r, centered=True, segs=40):
    c = Manifold.cylinder(h, r, r, segs, centered); return c.transform(align(v)).translate(list(p))
def chain(points, piece):
    parts = [Manifold.batch_hull([piece(a), piece(b)]) for a, b in zip(points[:-1], points[1:])]
    return Manifold.batch_boolean(parts, __import__('manifold3d').OpType.Add)
def sph(r): return lambda p: Manifold.sphere(r, 16).translate(list(p))
def ribbon(w, t): return lambda p: Manifold.cube([t, t, w], True).translate(list(p))

# ================= accessories in RAW model coordinates =================
# --- Koko: headband with wind-blown tails ---
koko_raw = trimesh.load(f"{IN}/koko.stl", force="mesh")
HB_Z = cfg.get("hb_z", 46.0); HB_H = cfg.get("hb_h", 1.05)
sec = koko_raw.section(plane_origin=[0, 0, HB_Z + HB_H/2], plane_normal=[0, 0, 1])
head_loop = max(sec.discrete, key=lambda L: len(L))[:, :2]
band_cs = CrossSection.hull_points(head_loop.tolist()).offset(cfg.get("hb_off", 0.12), JoinType.Round, circular_segments=24)
headband = band_cs.extrude(HB_H).translate([0, 0, HB_Z])
hb = band_cs.bounds(); knot = np.array([(hb[0]+hb[2])/2 + 0.3, hb[3] - 0.2, HB_Z + HB_H/2])
tails = Manifold()
for k, (dx, dz, ph) in enumerate([(0.55, 0.0, 0.0), (0.25, -0.9, 1.3)]):
    pts = [knot + [0, 0, -0.1*k]]
    for s in np.linspace(0.6, 7.5, 12):
        pts.append(knot + [dx*s, 0.75*s, dz*s*0.12 - 0.08*s + 0.45*np.sin(s*1.1 + ph)])
    tails = tails + chain(np.array(pts), ribbon(0.95, 0.4))
knot_m = Manifold.sphere(0.75, 20).scale([1.2, 0.8, 1.0]).translate(list(knot + [0, 0.25, 0]))
# --- Koko: single sheathed katana tucked at the right hip (-x side) ---
mouth = np.array([-4.9, -3.0, 25.6])
sdir = np.array([-0.30, 0.80, -0.52]); sdir /= np.linalg.norm(sdir)
upv = np.cross(sdir, [1, 0, 0]); upv = upv if upv[2] > 0 else -upv; upv /= np.linalg.norm(upv)
L_s, L_h = 18.5, 7.0
s_pts = [mouth + sdir*s + upv*(0.9*(s/L_s)**2) for s in np.linspace(0, L_s, 14)]
scabbard = chain(np.array(s_pts), lambda p: Manifold.sphere(0.6, 14).scale([1, 1, 1.25]).translate(list(p)))
kojiri = Manifold.sphere(0.68, 16).translate(list(s_pts[-1]))
h_pts = [mouth - sdir*(0.55 + s) - upv*(0.35*(s/L_h)**2) for s in np.linspace(0, L_h, 8)]
hilt = chain(np.array(h_pts), sph(0.52))
wraps = [cyl_along(h_pts[0] - sdir*(s), sdir, 0.25, 0.6) for s in np.linspace(0.8, L_h-0.8, 6)]
tsuba = cyl_along(mouth - sdir*0.3, sdir, 0.45, 1.45, segs=8)   # octagonal guard
kashira = Manifold.sphere(0.66, 16).translate(list(h_pts[-1]))
sageo = chain(np.array([mouth + sdir*1.2, mouth + sdir*1.2 + [0.9, 0.2, 0.6], [-4.4, -1.2, 26.4]]), sph(0.28))  # cord tying it to the waistband
katana = Manifold.batch_boolean([scabbard, kojiri, hilt, tsuba, kashira, sageo] + wraps, __import__('manifold3d').OpType.Add)
koko_aug = to_man(koko_raw) + headband + tails + knot_m + katana

# --- Koko: drawn katana gripped in his raised fist, blade resting back over his shoulder ---
if cfg.get("shoulder_sword", True):
    grip = np.array(cfg.get("grip", [-5.2, -2.3, 43.8]))
    bd = np.array(cfg.get("blade_dir", [-0.08, 0.72, -0.69])); bd /= np.linalg.norm(bd)
    e2 = np.array([0, 0, 1.0]) - bd*bd[2]; e2 /= np.linalg.norm(e2); e3 = np.cross(bd, e2)
    BL, BW, BT, sori = cfg.get("blade_len", 19.0), 0.9, 0.42, 0.7
    us = np.linspace(0, BL - 2.4, 20)
    top = [[u, BW/2 + sori*(u/BL)**2] for u in us]
    bot = [[u, -BW/2 + sori*(u/BL)**2] for u in us]
    tip = [[BL, sori + 0.35]]                       # pointed tip swept toward the back edge
    kiss = [[BL - 2.4 + 2.4*t, (BW/2 + sori)*(1 - t) + (sori + 0.35)*t - 0.15*np.sin(np.pi*t)] for t in np.linspace(0.2, 0.8, 4)]
    prof = top + kiss + tip + bot[::-1]
    blade2d = CrossSection([prof[::-1]]) if CrossSection([prof]).area() <= 0 else CrossSection([prof])
    M = np.eye(4); M[:3, 0], M[:3, 1], M[:3, 2] = bd, e2, e3
    guard_pt = grip + bd*2.0
    M[:3, 3] = guard_pt + bd*0.55 - e3*BT/2
    blade = blade2d.extrude(BT).transform(M[:3, :])
    habaki = cyl_along(guard_pt + bd*0.6, bd, 0.9, 0.62)
    tsuba2 = cyl_along(guard_pt, bd, 0.45, 1.45, segs=8)
    h2 = [grip + bd*1.75 - bd*s_ for s_ in np.linspace(0, 4.9, 7)]
    hilt2 = chain(np.array(h2), sph(0.55))
    kas2 = Manifold.sphere(0.66, 16).translate(list(h2[-1]))
    wraps2 = [cyl_along(grip + bd*1.2 - bd*s_, bd, 0.22, 0.62) for s_ in np.linspace(0.3, 4.2, 6)]
    shoulder_sword = Manifold.batch_boolean([blade, habaki, tsuba2, hilt2, kas2] + wraps2, __import__('manifold3d').OpType.Add)
    print("blade status", blade.status(), "vol", round(blade.volume(), 2), "blade∩body", round((blade ^ to_man(koko_raw)).volume(), 3))
    koko_aug = koko_aug + shoulder_sword

# --- Dani: wrist wrap on the punching arm with two short cloth ends ---
dani_raw = trimesh.load(f"{IN}/dani.stl", force="mesh")
n = np.array([0, -0.67, 0.74]); n /= np.linalg.norm(n)
wc = np.array([10.8, -15.9, 31.6])
wrap = (cyl_along(wc, n, 1.3, 2.25) + cyl_along(wc - n*1.25, n, 0.9, 2.1) + cyl_along(wc - n*2.2, n, 0.8, 2.15))
ends = Manifold()
for k, off in enumerate([0.0, 0.7]):
    st = wc - n*(1.2 + off) + np.array([1.8, 0, -1.0])
    pts = [st + np.array([0.9*s*0.35, 0.25*s, -0.9*s]) + [0, 0, 0.25*np.sin(s*1.4 + k)] for s in np.linspace(0, 3.2 - 0.7*k, 6)]
    ends = ends + chain(np.array(pts), ribbon(0.8, 0.35))
dani_aug = to_man(dani_raw) + wrap + ends

# --- Dani: wind-blown hero scarf ---
if cfg.get("scarf", True):
    sec_n = dani_raw.section(plane_origin=[0, 0, 33.8], plane_normal=[0, 0, 1])
    neck = min(sec_n.discrete, key=lambda L: np.linalg.norm(L.mean(0)[:2] - [-0.3, 1.8]))[:, :2]
    ncs = CrossSection.hull_points(neck.tolist())
    sz = cfg.get("scarf_z", 31.0)
    def loop_tube(off, z, r, dip):
        poly = np.array(ncs.offset(off, JoinType.Round, circular_segments=48).to_polygons()[0])
        cy = poly[:, 1].mean(); span = np.ptp(poly[:, 1])
        P = [[x, y, z - dip*max(0.0, (cy - y)/(span/2))**1.5] for x, y in poly]
        P.append(P[0])
        return chain(np.array(P), lambda q: Manifold.sphere(r, 16).scale([1, 1, 1.45]).translate(list(q)))
    roll1 = chain_ell = loop_tube(0.7, sz + 0.6, 1.25, 1.0)
    roll2 = Manifold()
    nb = ncs.bounds()
    sknot = np.array([nb[0] - 0.2, (nb[1]+nb[3])/2 + 1.0, sz + 0.9])          # knot at back of neck, his right side (away from Koko)
    sk = Manifold.sphere(1.0, 20).scale([1.1, 0.9, 1.0]).translate(list(sknot))
    stails = Manifold()
    for k, (L_, dz, ph) in enumerate([(16.0, 0.0, 0.0), (12.0, -1.6, 1.7)]):
        pts = [sknot]
        for t in np.linspace(0.08, 1, 16):
            pts.append(sknot + [-0.86*L_*t, 0.50*L_*t, dz*t + 1.8*t - 4.2*t*t + 1.4*np.sin(t*6.8 + ph)*t])
        w0, w1 = 2.8, 2.0
        parts = [Manifold.batch_hull([Manifold.cube([0.7, 0.7, w0 + (w1-w0)*i/len(pts)], True).translate(list(a)),
                                      Manifold.cube([0.7, 0.7, w0 + (w1-w0)*(i+1)/len(pts)], True).translate(list(b))])
                 for i, (a, b) in enumerate(zip(pts[:-1], pts[1:]))]
        stails = stails + Manifold.batch_boolean(parts, __import__('manifold3d').OpType.Add)
    dani_aug = dani_aug + roll1 + roll2 + sk + stails

# --- Dani: power aura flaring off the punching fist ---
if cfg.get("aura", True):
    fc = np.array([10.3, -18.4, 34.6])
    u0 = np.array([0, 0, 1.0]) - n*n[2]; u0 /= np.linalg.norm(u0); v0 = np.cross(n, u0)
    flames = []
    nfl = cfg.get("n_flames", 9)
    for i in range(nfl):
        th0 = -1.7 + 3.4*i/(nfl-1)
        L_ = cfg.get('fist_L', 10.5) + 3.0*np.cos(th0*0.9) + 1.2*np.sin(i*2.7)
        pts, rads = [], []
        for t in np.linspace(0, 1, 14):
            th = th0*(1 - 0.35*t) + 0.25*np.sin(t*5 + i)
            r = 1.85 + 1.2*t
            pts.append(fc + n*(0.6 - L_*t) + (np.cos(th)*u0 + np.sin(th)*v0)*r + np.array([0, 0, 6.0*t**1.5]))
            rads.append(1.3*(1 - t)**0.75 + 0.25*t)
        parts = [Manifold.batch_hull([Manifold.sphere(ra, 12).translate(list(a)), Manifold.sphere(rb, 12).translate(list(b))])
                 for a, b, ra, rb in zip(pts[:-1], pts[1:], rads[:-1], rads[1:])]
        flames.append(Manifold.batch_boolean(parts, __import__('manifold3d').OpType.Add))
    aura = Manifold.batch_boolean(flames, __import__('manifold3d').OpType.Add)
    dani_aug = dani_aug + aura


# --- Dani: full-body power aura, flame tongues rising off shoulders, back and arms ---
body_flames = []
if cfg.get("body_aura", True):
    pts_s, fidx = trimesh.sample.sample_surface(dani_raw, 6000, seed=3)
    nrm = dani_raw.face_normals[fidx]
    ok = (pts_s[:, 2] > 12) & (pts_s[:, 2] < 33.0) & ((nrm[:, 2] > 0.5) | (nrm[:, 1] > 0.25) | ((np.abs(nrm[:, 0]) > 0.75) & (nrm[:, 1] > -0.15)))
    ok &= ~((np.abs(pts_s[:, 0]) < 5.5) & (pts_s[:, 1] < 3) & (pts_s[:, 2] > 28))   # keep clear of face/chin
    ok &= ~((pts_s[:, 1] < 7) & (nrm[:, 2] < 0.5) & (np.abs(pts_s[:, 0]) < 10.5))   # no flames sprouting from the chest/abs
    ok &= np.linalg.norm(pts_s - [10.3, -18.4, 34.6], axis=1) > 6      # leave the fist to its own fire
    cand = np.nonzero(ok)[0]; rng2 = np.random.default_rng(11); rng2.shuffle(cand)
    chosen = []
    for i in cand:
        if all(np.linalg.norm(pts_s[i] - pts_s[j]) > cfg.get("flame_gap", 4.4) for j in chosen): chosen.append(i)
    for k, i in enumerate(chosen):
        p0, nv = pts_s[i] - nrm[i]*0.5, nrm[i]
        side = np.cross(nv, [0, 0, 1.0]); side = side/np.linalg.norm(side) if np.linalg.norm(side) > 1e-3 else np.array([1.0, 0, 0])
        L_ = rng2.uniform(8.0, 13.0) * (1.15 if nv[2] > 0.5 else 1.0); r0 = rng2.uniform(1.5, 2.0); ph = rng2.uniform(0, 6.28)
        P, R = [], []
        for t in np.linspace(0, 1, 16):
            P.append(p0 + nv*(2.4*t) + np.array([0, 1.4*t, L_*t**1.3]) + side*1.3*np.sin(t*5.0 + ph)*t)
            R.append(r0*(1 - t)**0.85 + 0.28*t)
        # a smaller licking side-flame for a forked look
        P2, R2 = [], []
        for t in np.linspace(0, 1, 10):
            P2.append(p0 + nv*(1.6*t) + side*(1.0 + 0.8*t)*np.sign(np.sin(ph)) + np.array([0, 0.9*t, 0.6*L_*t**1.3]) + side*0.6*np.sin(t*5 + ph + 1.5)*t)
            R2.append(0.75*r0*(1 - t)**0.85 + 0.25*t)
        P, R = P + [None] + P2, R + [None] + R2
        parts = [Manifold.batch_hull([Manifold.sphere(ra, 14).translate(list(a)), Manifold.sphere(rb, 14).translate(list(b))])
                 for a, b, ra, rb in zip(P[:-1], P[1:], R[:-1], R[1:]) if a is not None and b is not None]
        fl = Manifold.batch_boolean(parts, __import__('manifold3d').OpType.Add)
        fv = fl.to_mesh().vert_properties[:, :3]
        front = fv[(fv[:, 1] < 2.5) & (np.abs(fv[:, 0]) < 8.0) & (fv[:, 2] < 31)]
        if len(front): continue          # would show through the chest
        body_flames.append(fl)
    print("body flames", len(body_flames))

# ================= placement (transforms computed from ORIGINAL meshes) =================
ks = cfg["koko_h"] / koko_raw.extents[2]; ds = ks * cfg["dani_rel"]
def place_T(raw, s, yaw, x, y, z, foot_z):
    v = raw.vertices; low = v[v[:, 2] < raw.bounds[0, 2] + foot_z]
    c = [(low[:, 0].min()+low[:, 0].max())/2, (low[:, 1].min()+low[:, 1].max())/2, raw.bounds[0, 2]]
    T = trimesh.transformations.translation_matrix([x, y, z]) @ trimesh.transformations.rotation_matrix(np.radians(yaw), [0, 0, 1]) \
        @ trimesh.transformations.scale_matrix(s) @ trimesh.transformations.translation_matrix(-np.array(c))
    return T, low, c

# ================= base =================
W, D, H = 124.0, 72.0, 14.0
def oct_cs(w, d, ch): return CrossSection([[[-w/2+ch, -d/2], [w/2-ch, -d/2], [w/2, -d/2+ch], [w/2, d/2-ch], [w/2-ch, d/2], [-w/2+ch, d/2], [-w/2, d/2-ch], [-w/2, -d/2+ch]]])
def slab(cs_fn, w, d, ch, h, z0, inset):
    body = cs_fn(w, d, ch).extrude(h - inset)
    top = Manifold.batch_hull([cs_fn(w, d, ch).extrude(0.01), cs_fn(w-2*inset, d-2*inset, max(ch-inset*0.4, 0.5)).extrude(0.01).translate([0, 0, inset])])
    return (body + top.translate([0, 0, h - inset])).translate([0, 0, z0])
foot = slab(oct_cs, W+4, D+4, 11, 3.0, 0, 1.0)
body = slab(oct_cs, W, D, 9, H-3+0.01, 2.99, 1.4)
top_z = H
front_y = -D/2

def text_cs(s, height, font, spacing=0.06, space=0.30):
    fp = FontProperties(fname=font); ref = TextPath((0, 0), "H", size=1, prop=fp).get_extents().height
    size = height/ref; polys, x = [], 0.0
    for ch in s:
        if ch == " ": x += size*space; continue
        tp = TextPath((x, 0), ch, size=size, prop=fp)
        for p in tp.to_polygons(closed_only=True):
            if len(p) >= 3: polys.append(np.asarray(p, float))
        x = tp.get_extents().x1 + size*spacing
    cs = CrossSection(polys, FillRule.EvenOdd); b = cs.bounds()
    return cs.translate([-(b[0]+b[2])/2, -(b[1]+b[3])/2])

# comic front lettering: raised letters on a recessed "panel" with a thick outline
ft = text_cs(cfg["front_text"], 6.4, cfg["font"], spacing=0.13, space=0.38)
fb = ft.bounds(); print("front text width", round(fb[2]-fb[0], 1))
outline = ft.offset(0.7, JoinType.Round, circular_segments=12)
zt = 3 + (H-3)/2 - 0.3
recess = outline.extrude(2.0).rotate([90, 0, 0]).translate([0, front_y + 1.0, zt])
letters = ft.extrude(1.6).rotate([90, 0, 0]).translate([0, front_y + 1.0 + 0.0, zt])

# impact cracks on the top radiating from Koko's feet
def crack_cs(start, ang, length, wid):
    pts = [np.array(start, float)]; a = ang
    while np.linalg.norm(pts[-1]-pts[0]) < length:
        a += rng.uniform(-0.6, 0.6); step = rng.uniform(3, 5.5)
        pts.append(pts[-1] + step*np.array([np.cos(a), np.sin(a)]))
    segs = []
    for i, (p, q) in enumerate(zip(pts[:-1], pts[1:])):
        w = wid*(1 - i/len(pts))*0.9 + 0.35
        segs.append(CrossSection.batch_hull([CrossSection.circle(w/2, 10).translate(list(p)), CrossSection.circle(max(w/2-0.1, 0.2), 10).translate(list(q))]))
    return CrossSection.batch_boolean(segs, __import__('manifold3d').OpType.Add)
kx, ky = cfg["koko_x"], cfg["koko_y"]
cracks = CrossSection()
for ang, ln in [(-0.35, 34), (0.5, 26), (1.35, 18), (2.4, 20), (-1.2, 22), (-2.0, 16), (3.0, 12)]:
    cracks = cracks + crack_cs([kx + 9*np.cos(ang), ky + 7*np.sin(ang)], ang, ln, 1.4)
crater = CrossSection.circle(13, 9).scale([1.0, 0.75]).translate([kx, ky])
ring = crater - crater.offset(-1.1, JoinType.Miter)
cut_area = oct_cs(W-8, D-8, 6) - CrossSection.circle(24, 40).translate([cfg["dani_x"], cfg["dani_y"]+4])
top_cuts = ((cracks + ring) ^ cut_area).extrude(2.0).translate([0, 0, top_z - 0.9])

# rock pillar for Dani's bust
Td, d_low, d_c = place_T(dani_raw, ds, cfg["dani_yaw"], cfg["dani_x"], cfg["dani_y"], 0, 2.0)
slab_r = np.hypot(*(np.ptp(d_low[:, :2], 0)*ds/2)) + 0.6
ph = cfg["ped_h"]
def ring_pts(R, z, nside=7, jit=0.12, rot=0.0):
    a = np.linspace(0, 2*np.pi, nside, endpoint=False) + rot + rng.uniform(-0.15, 0.15, nside)
    r = R*(1 + rng.uniform(-jit, jit, nside)); return [[ri*np.cos(ai), ri*np.sin(ai), z] for ri, ai in zip(r, a)]
def pts_hull(P): return Manifold.batch_hull([Manifold.sphere(0.01, 4).translate(p) for p in P])
Rt = slab_r/np.cos(np.pi/7) + 1.2
sink = 4.0*ds
rock = pts_hull(ring_pts(Rt+4.0, top_z-0.5, 9, 0.07) + ring_pts(Rt+2.2, top_z + ph*0.5, 9, 0.06, 0.2)
                + [[p[0], p[1], top_z+ph] for p in ring_pts(Rt+0.3, 0, 9, 0.015, 0.4)])
side = pts_hull(ring_pts(9, top_z-0.5, 7, 0.15, 0.0) + ring_pts(6, top_z + ph*0.42, 6, 0.2, 0.5))
side = side.translate([Rt*0.75, -Rt*0.45, 0])
chunks = Manifold()
for (cx, cy, r) in [(Rt+7, -9, 3.0), (-Rt-3, -6, 2.4)]:
    chunks = chunks + pts_hull([[cx+q[0], cy+q[1], top_z-0.5+abs(q[2])] for q in (rng.normal(size=(9, 3))*[r, r, r*0.8])])
pillar = (rock + chunks).translate([cfg["dani_x"], cfg["dani_y"], 0])
Td[2, 3] += top_z + ph - sink

# Koko stands in the crater
Tk, _, _ = place_T(koko_raw, ks, cfg["koko_yaw"], kx, ky, top_z - 1.2, 1.5)

# manga burst backdrop with speed lines
bz, by, bt = 72.0, D/2 - 5.0, 4.0
nsp = 26; ang = np.linspace(0, 2*np.pi, 2*nsp, endpoint=False) + np.pi/2
rad = np.where(np.arange(2*nsp) % 2 == 0, 62, 47) * (1 + rng.uniform(-0.09, 0.09, 2*nsp))
burst = CrossSection([np.stack([rad*np.cos(ang), rad*np.sin(ang)], 1).tolist()])
clip = CrossSection.square([W-10, 300], True).translate([0, 150 + 0.0 - bz + top_z - 1])
burst = burst ^ clip                       # flatten bottom onto the base
lines = []
for a in np.linspace(0, 2*np.pi, 64, endpoint=False) + rng.uniform(-0.03, 0.03, 64):
    r0, r1 = rng.uniform(26, 36), 70; w = rng.uniform(0.9, 1.7)
    d_ = np.array([np.cos(a), np.sin(a)]); p_ = np.array([-d_[1], d_[0]])
    lines.append(CrossSection([[ (d_*r0).tolist(), (d_*r1 - p_*w).tolist(), (d_*r1 + p_*w).tolist() ]]))
speed = CrossSection.batch_boolean(lines, __import__('manifold3d').OpType.Add) ^ burst.offset(-2.2, JoinType.Miter)
def on_panel(cs, thick, y_face):  # extrude a 2D shape (x,z) into a vertical slab whose front is at y_face
    return cs.extrude(thick).rotate([90, 0, 0]).translate([0, y_face + thick, bz])
panel = on_panel(burst, bt, by)
lines3d = on_panel(speed, 1.0, by - 0.9)
backdrop = panel + lines3d
jp = text_cs(cfg["jp_text"], 9.0, cfg["jp_font"], spacing=0.04)
bk = text_cs(cfg["back_text"], 5.5, cfg["font"], spacing=0.07)
print("jp width", round(np.ptp(np.array(jp.bounds()).reshape(2, 2)[:, 0]), 1))
def back_engrave(cs, z):
    return cs.extrude(2).rotate([90, 0, 180]).translate([0, by + bt - 0.8, 0]).translate([0, 0, z])
backdrop = backdrop - back_engrave(jp.translate([0, 0]), bz + 6) - back_engrave(bk, bz - 8)

base = (foot + body - recess + letters - top_cuts) + pillar + backdrop
koko_m = koko_aug.transform(Tk[:3, :]); dani_m = dani_aug.transform(Td[:3, :])
print("dani/koko overlap", round((dani_m ^ koko_m).volume(), 3), " koko/backdrop", round((koko_m ^ backdrop).volume(), 3), " dani/backdrop", round((dani_m ^ backdrop).volume(), 3))
kept = []
for fl in body_flames:
    w = fl.transform(Td[:3, :])
    if (w ^ koko_m).volume() < 1e-3 and (w ^ backdrop).volume() < 1e-3: kept.append(w)
print("body flames kept", len(kept), "of", len(body_flames))
if kept: dani_m = dani_m + Manifold.batch_boolean(kept, __import__('manifold3d').OpType.Add)
print("dani(final)/koko overlap", round((dani_m ^ koko_m).volume(), 3))
full = base + koko_m + dani_m
print("status", full.status(), "genus", full.genus())
ft_ = to_tm(full); print("bounds", ft_.bounds.round(1).tolist(), "faces", len(ft_.faces))
ft_.export(f"{OUT}/Koko_Birthday_Anime.stl")
to_tm(base).export(f"{OUT}/anime_base.stl"); to_tm(koko_m).export(f"{OUT}/anime_koko.stl"); to_tm(dani_m).export(f"{OUT}/anime_dani.stl")
