import sys, json, numpy as np, trimesh
from manifold3d import Manifold, Mesh, CrossSection, FillRule, JoinType
from matplotlib.textpath import TextPath
from matplotlib.font_manager import FontProperties

IN, OUT = sys.argv[1], sys.argv[2]
cfg = dict(
    koko_h=100.0,            # Koko standing height, mm
    dani_rel=0.62,           # Dani scale relative to Koko (head-size match)
    dani_yaw=22, koko_yaw=-14,
    dani_x=-25, koko_x=24, dani_y=-2, koko_y=2,
    ped_h=34,
    front_text="HAPPY BIRTHDAY KOKO", back_text="DANI & KOKO  ·  2026",
    font="/System/Library/Fonts/Supplemental/Futura.ttc",
)
if len(sys.argv) > 3: cfg.update(json.loads(sys.argv[3]))

def to_man(tm):
    return Manifold(Mesh(vert_properties=np.asarray(tm.vertices, np.float32), tri_verts=np.asarray(tm.faces, np.uint32)))
def to_tm(man):
    m = man.to_mesh(); return trimesh.Trimesh(m.vert_properties[:, :3], m.tri_verts, process=False)

def rrect(w, d, r):
    return CrossSection.square([w-2*r, d-2*r], center=True).offset(r, JoinType.Round, circular_segments=48)

def slab(w, d, h, r, z0, top_inset=0.0):
    # rounded slab; top edge chamfered by shrinking the top face
    cs = rrect(w, d, r)
    if top_inset <= 0:
        return cs.extrude(h).translate([0, 0, z0])
    body = cs.extrude(h - top_inset)
    cham = Manifold.batch_hull([cs.extrude(0.01), rrect(w-2*top_inset, d-2*top_inset, max(r-top_inset, 0.5)).extrude(0.01).translate([0, 0, top_inset])])
    return (body + cham.translate([0, 0, h - top_inset])).translate([0, 0, z0])

def text_cs(s, height, font, spacing=0.14):
    fp = FontProperties(fname=font)
    polys, x = [], 0.0
    ref = TextPath((0, 0), "H", size=1, prop=fp).get_extents().height
    size = height / ref
    for ch in s:
        if ch == " ":
            x += size * 0.32; continue
        tp = TextPath((x, 0), ch, size=size, prop=fp)
        for p in tp.to_polygons(closed_only=True):
            if len(p) >= 3: polys.append(np.asarray(p[:-1] if np.allclose(p[0], p[-1]) else p, float))
        x = tp.get_extents().x1 + size * spacing if len(tp.vertices) else x + size*0.3
    cs = CrossSection(polys, FillRule.EvenOdd)
    b = cs.bounds()
    return cs.translate([-(b[0]+b[2])/2, -(b[1]+b[3])/2])

# ---------- statues ----------
koko = trimesh.load(f"{IN}/koko.stl", force="mesh")
dani = trimesh.load(f"{IN}/dani.stl", force="mesh")
ks = cfg["koko_h"] / koko.extents[2]
ds = ks * cfg["dani_rel"]
def place(tm, s, yaw, x, y, z):
    t = tm.copy(); t.apply_translation([-(t.bounds[0,0]+t.bounds[1,0])/2, -(t.bounds[0,1]+t.bounds[1,1])/2, -t.bounds[0,2]])
    t.apply_scale(s)
    t.apply_transform(trimesh.transformations.rotation_matrix(np.radians(yaw), [0,0,1]))
    t.apply_translation([x, y, z]); return t

# ---------- plinth ----------
W, D = 120.0, 58.0
lower_h, upper_h = 5.0, 13.0
lower = slab(W, D, lower_h, 6, 0, top_inset=1.2)
upper = slab(W-6, D-6, upper_h, 4, lower_h - 0.01, top_inset=1.0)
top_z = lower_h + upper_h

# pedestal (column) for Dani's bust
dani_tmp = place(dani, ds, 0, 0, 0, 0)
foot = dani_tmp.bounds  # footprint of bust base
bw, bd = (foot[1,0]-foot[0,0]), (foot[1,1]-foot[0,1])
# bust base footprint at z<3 only
low = dani_tmp.vertices[dani_tmp.vertices[:,2] < 2.0]
bw, bd = np.ptp(low[:,0]) + 4, np.ptp(low[:,1]) + 4
cs_c = max(bw, bd)
ph = cfg["ped_h"]
ped = (slab(cs_c+5, cs_c+5, 3.0, 2, top_z-0.01, top_inset=0.8)
       + slab(cs_c-5, cs_c-5, ph-6, 1.0, top_z+2.9)
       + slab(cs_c+5, cs_c+5, 3.2, 2, top_z+ph-3.2, top_inset=0.8))
ped = ped.rotate([0, 0, cfg["dani_yaw"]]).translate([cfg["dani_x"], cfg["dani_y"], 0])
ped_top = top_z + ph

# Dani bust: center its base footprint on the column
cx, cy = (low[:,0].min()+low[:,0].max())/2, (low[:,1].min()+low[:,1].max())/2
dt = dani.copy(); dt.apply_translation([-(dt.bounds[0,0]+dt.bounds[1,0])/2, -(dt.bounds[0,1]+dt.bounds[1,1])/2, -dt.bounds[0,2]])
dt.apply_scale(ds); dt.apply_translation([-cx, -cy, 0])
dt.apply_transform(trimesh.transformations.rotation_matrix(np.radians(cfg["dani_yaw"]), [0,0,1]))
dt.apply_translation([cfg["dani_x"], cfg["dani_y"], ped_top - 0.4])

# Koko: center feet footprint
kt = place(koko, 1.0, 0, 0, 0, 0)
kl = kt.vertices[kt.vertices[:,2] < 1.5]
kcx, kcy = (kl[:,0].min()+kl[:,0].max())/2, (kl[:,1].min()+kl[:,1].max())/2
kt.apply_translation([-kcx, -kcy, 0]); kt.apply_scale(ks)
kt.apply_transform(trimesh.transformations.rotation_matrix(np.radians(cfg["koko_yaw"]), [0,0,1]))
kt.apply_translation([cfg["koko_x"], cfg["koko_y"], top_z - 0.4])

# ---------- engraving ----------
depth = 0.8
front_y = -(D-6)/2
ft = text_cs(cfg["front_text"], 5.0, cfg["font"])
fb = ft.bounds(); print("front text width", round(fb[2]-fb[0],1))
front_cut = ft.extrude(depth + 1).rotate([90, 0, 0]).translate([0, front_y + depth, lower_h + upper_h/2 - 0.5])
bt = text_cs(cfg["back_text"], 4.2, cfg["font"])
back_cut = bt.extrude(depth + 1).rotate([90, 0, 180]).translate([0, -front_y - depth, lower_h + upper_h/2 - 0.5])

base = (lower + upper + ped) - front_cut - back_cut
dani_m, koko_m = to_man(dt), to_man(kt)
print("intersections: dani/koko", round((dani_m ^ koko_m).volume(), 3))
full = base + dani_m + koko_m
for name, m in [("base", base), ("full", full)]:
    print(name, "status", m.status(), "genus", m.genus(), "vol", round(m.volume(),1))
full_tm = to_tm(full)
print("final bounds", full_tm.bounds.round(1).tolist(), "faces", len(full_tm.faces))
full_tm.export(f"{OUT}/Koko_Birthday_Statue.stl")
to_tm(base).export(f"{OUT}/parts_base.stl"); dt.export(f"{OUT}/parts_dani.stl"); kt.export(f"{OUT}/parts_koko.stl")
